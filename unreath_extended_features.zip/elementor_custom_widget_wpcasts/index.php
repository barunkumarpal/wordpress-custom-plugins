<?php
/* 
Plugin Name: Custom Elementor Widget WPCasts
Version: 1.0.0
Description: Testing to create a Custom Widget for Elementor
Author: Barun
Text Domain: wpc
*/

if( !defined('ABSPATH')){
    die;
}


// Plugin Path
define('WPC_PLUGIN_URL', __FILE__);

$plugin_path = dirname(WPC_PLUGIN_URL);


// Create Custom Elementor Widget
require_once($plugin_path.'/elementor/custom_widgets.php');