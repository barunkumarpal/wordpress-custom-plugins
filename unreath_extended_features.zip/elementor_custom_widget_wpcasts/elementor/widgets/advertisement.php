<?php

namespace WPC\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if( !defined('ABSPATH')) exit;

class Advertisement extends Widget_Base{
    public function get_name() {

        return 'advertisement';
    }

	public function get_title() {

        return 'Advertisement';
    }

	public function get_icon() {

        return 'fa fa-camera';
    }

	public function get_categories() {

        return ['general'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
			'section_content',
			[
				'label' => 'Settings'			
			]
		);

		$this->add_control(
			'label_heading',
			[
				'label' => 'Label Heading',
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'My Example Heading'
			]
        );
        
        $this->add_control(
			'content_heading',
			[
				'label' => 'Content Heading',
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'My Example Content Heading'
			]
        );
        
        $this->add_control(
			'content',
			[
				'label' => 'Content',
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => 'My Example Content'
			]
		);

		$this->end_controls_section();

    }

    protected function render() {    
        
        // Frontend view after update
        require_once(__DIR__.'/advertisement/php_render.php');
    }

    protected function _content_template() {

        // Backend view while editing
        require_once(__DIR__.'/advertisement/js_render.php');
    }
    
}