<?php

$settings = $this->get_settings_for_display();

$this->add_inline_editing_attributes('label_heading', 'basic');

$this->add_render_attribute(
    'label_heading',
    [
        'class' => ['label_heading bg-primary p-2 text-white'],
    ]
)

?>

<div class="bg-light">
    <h2 <?php echo $this->get_render_attribute_string('label_heading'); ?>><?php echo $settings['label_heading']; ?></h2>
    <h4 class="p-2 mt-2 mb-2 text-center"><?php echo $settings['content_heading']; ?></h4>
    <p class=" p-2 mt-2"><?php echo $settings['content']; ?></p>
</div>




<?php
        