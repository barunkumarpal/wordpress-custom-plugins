<#
view.addInlineEditingAttributes('label_heading', 'basic');

view.addRenderAttribute(
    'label_heading',
    {
        'class' : ['label_heading bg-primary p-2 text-white'],
    }
);

#>


<div class="bg-light">
    <h2 {{{ view.getRenderAttributeString( 'label_heading') }}}>{{{ settings.label_heading}}}</h2>
    <h4 class="p-2 mt-2 mb-2 text-center">{{{ settings.content_heading}}}</h4>
    <p class=" p-2 mt-2">{{{ settings.content}}}</p>
</div>