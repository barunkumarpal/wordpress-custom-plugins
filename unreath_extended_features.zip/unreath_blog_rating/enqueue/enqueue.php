<?php
function ubr_enqueue_scripts(){

wp_enqueue_style('ubr_rateit_css', plugins_url('/rateit/scripts/rateit.css', UBR_PLUGIN_URL) );

wp_enqueue_script( 
    'ubr_rateit_jquery_min_js',
     plugins_url('/rateit/scripts/jquery.rateit.min.js', UBR_PLUGIN_URL), 
     ['jquery'], 
     '1.0.0', 
     true );

wp_enqueue_script( 
    'ubr_rateit_main_js',
     plugins_url('/rateit/scripts/main.js', UBR_PLUGIN_URL) , 
     ['jquery'], 
     '1.0.0', 
     true );

wp_localize_script('ubr_rateit_main_js', 'ubr_ajax_obj', [ 
        'ajax_url' => admin_url('admin-ajax.php'),
        'home_url' => home_url('/')
        ]);
}