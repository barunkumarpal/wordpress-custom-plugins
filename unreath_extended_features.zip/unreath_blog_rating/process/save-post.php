<?php

function ubr_save_post_admin($post_id, $post, $update){

    $post_data = get_post_meta($post_id, 'post_data', true);
    $post_data = empty($post_data) ? [] : $post_data;
    $post_data['rating'] = isset($post_data['rating']) ? absint($post_data['rating']) :  0;
    $post_data['rating_count'] = isset($post_data['rating_count']) ? absint($post_data['rating_count']) :  0;

    update_post_meta($post_id, 'post_data', $post_data);

}