<?php
function ubr_manage_post_admin_columns($column, $post_id){
    switch($column){
        case 'count':
            $custom_data    = get_post_meta($post_id, 'post_data', true);
            echo isset($custom_data['rating_count']) ? $custom_data['rating_count'] : 0;
            break;
        case 'rating':
            $custom_data    = get_post_meta($post_id, 'post_data', true);
            echo isset($custom_data['rating']) ? $custom_data['rating'] : 'N/A';
            break;
        default:
            break;
    }
}