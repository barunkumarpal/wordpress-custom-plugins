<?php
function ubr_add_new_post_admin_columns( $columns ){
   
        $post_type = get_post_type();
        if ( $post_type == 'post' ) {
            $new_columns = array(
                'count' => __( 'Ratings Count', 'ubr' ),               
                'rating' =>  __('Average Rating', 'ubr')
            );
            return array_merge($columns, $new_columns);
        }
   
}