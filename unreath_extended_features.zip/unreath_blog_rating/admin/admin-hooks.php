<?php 
function ubr_post_admin_init(){

    // Add new admin columns for Posts
    include('admin-columns.php');
    add_filter('manage_post_posts_columns', 'ubr_add_new_post_admin_columns');

    // Show Custom Column Data
    include('show-custom-admin-column-data.php');
    add_action('manage_posts_custom_column', 'ubr_manage_post_admin_columns', 10, 2);
}