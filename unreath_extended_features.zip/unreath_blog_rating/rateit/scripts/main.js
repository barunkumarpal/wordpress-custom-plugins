(function($){
    $("#post_rating").bind( 'rated', function(){
        $(this).rateit( 'readonly', true );

        var form        =   {
            action:         'ubr_post_rating',
            rid:            $(this).data( 'rid' ),
            rating:         $(this).rateit( 'value' )
        };

        $.post( ubr_ajax_obj.ajax_url, form, function(data){
            
        });
    });
})(jQuery);