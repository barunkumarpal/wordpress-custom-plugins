<?php
/* 
Plugin Name: Unreath Blog Rating
Version: 1.0.0
Description: This plugin to be used to rate the blog
Author: Barun
Text Domain: ubr
*/

if( !defined('ABSPATH')){
    die;
}

if(!function_exists('add_action')){
    exit;
}



// Plugin Path
define('UBR_PLUGIN_URL', __FILE__);

$plugin_path = dirname(UBR_PLUGIN_URL);

// Activate Plugin Hook
include('activate.php');
register_activation_hook(__FILE__, 'ubr_activate_plugin');

// Save Post
 include($plugin_path.'/process/save-post.php');
 add_action('save_post', 'ubr_save_post_admin', 10, 3);

// Add Blog Filter 
include( $plugin_path.'/filter/blog-content-filter.php');
add_filter('the_content', 'ubr_blog_content_filter');

// Load Style and JS
include($plugin_path.'/enqueue/enqueue.php');
add_action('wp_enqueue_scripts', 'ubr_enqueue_scripts');

// Rating Ajax Request
include( $plugin_path.'/process/save-post-rating.php');
add_action('wp_ajax_ubr_post_rating', 'ubr_save_post_rating');

// Guest can Rate Post
add_action('wp_ajax_nopriv_ubr_post_rating', 'ubr_save_post_rating');

// Admin hooks
include( $plugin_path.'/admin/admin-hooks.php');
add_action('admin_init', 'ubr_post_admin_init');