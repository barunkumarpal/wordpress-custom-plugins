<?php
function ubr_blog_content_filter( $content ){
    if( !is_singular('post') ){
        return $content;
    }

    global $post, $wpdb;

    $post_data = get_post_meta( $post->ID, 'post_data', true);

    //$rating_html = file_get_contents( plugins_url( '/templates/rating-content-template.php', UBR_PLUGIN_URL));

     $file_path = '/templates/rating-content-template.php';

     $actual_file_path = plugins_url( $file_path , UBR_PLUGIN_URL);

     $rating_html = file_get_contents( $actual_file_path, true );

    //$rating_html = file_get_contents( plugins_url( '/templates/rating-content-template.php' , UBR_PLUGIN_URL), true );

    $replace = str_replace( 'RATE_I18N', __('Rating', 'ubr'), $rating_html);

    $replace = str_replace( 'RECIPE_ID', $post->ID, $replace);

    $replace = str_replace( 'POST_RATING', $post_data['rating'], $replace);

    // Check user already rated
     $user_IP = $_SERVER['REMOTE_ADDR'];

    $rating_count = $wpdb->get_var( 

                    $wpdb->prepare(
    
        "SELECT COUNT(*) FROM `" . $wpdb->prefix. "post_ratings`
        WHERE post_id=%d AND user_ip=%s",

        $post->ID, $user_IP
        )     
    );

    if( $rating_count > 0 ){
        $replace = str_replace('READONLY_PLACEHOLDER', 'data-rateit-readonly="true"', $replace);
    } else{
        $replace = str_replace('READONLY_PLACEHOLDER', '', $replace);
    }

   return  $replace . $content;
}