<?php

function apf_enqueue_scripts(){
    wp_register_script('apf_main_js', plugins_url('/js/main.js', APF_PLUGIN_URL),
    ['jquery'], '1.0.0', true );

    wp_localize_script('apf_main_js', 'apf_wp_ajax_obj', [ 
        'ajax_url' => admin_url('admin-ajax.php'),
        'home_url' => home_url('/')
        ]);

    wp_enqueue_script('apf_main_js');
}