<?php

function apf_submit_post_process(){
    $output = ['status' => 1 ];

     if(empty($_POST['title'])){
         wp_send_json( $output );
     }

     global $wpdb;

     $title = sanitize_text_field( $_POST['title'] );
     $content = wp_kses_post( $_POST['content'] );
     $post_data = [];
     $post_data['rating'] = 0;
     $post_data['rating_count'] = 0;


     $post_id = wp_insert_post([
        'post_content'  => $content,
        'post_name'     => $title,
        'post_title'     => $title,
        'post_status' => 'pending',
        'post_type' => 'post'
     ]);

     update_post_meta( $post_id, 'post_data', $post_data);     
   

    $output['status'] = 2;
     wp_send_json($output);

    
}

