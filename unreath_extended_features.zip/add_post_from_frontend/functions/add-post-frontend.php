<?php
function apf_add_post_frontend(){
    $creatorHTML = file_get_contents( plugins_url('/templates/add-post-frontend-form.php', APF_PLUGIN_URL) , true); 
   
    $editorHTML = r_generate_content_editor();
    $creatorHTML = str_replace('CONTENT_EDITOR', $editorHTML, $creatorHTML);

    return $creatorHTML;
}

function r_generate_content_editor(){
    ob_start();
    wp_editor('', 'add_post_content_editor');
    $editor_contents = ob_get_clean();
    return $editor_contents;
}