(function($){   

// Add Recipe

    $("#add-post-form").on('submit', function(e){
        e.preventDefault();

        $(this).hide();
        $("#add_post_status").html(
            '<div class="alert alert-info">Please wait! We are submitting your Post.</div>'
        );

        var form = {
            action: 'apf_submit_user_post',
            title: $('#apf_inputTitle').val(),
            content: tinymce.activeEditor.getContent(),
           // attachment_id: $('#r_inputImgID').val()
        }

        $.post(apf_wp_ajax_obj.ajax_url, form, function(data){
            if(data.status == 2){
                $('#add_post_status').html(
                    '<div class="alert alert-success">Post submitted successfully!</div>'
                );
            } else{
                $('#add_post_status').html(
                    '<div class="alert alert-danger">Unable to submit. Please fill in all fields.</div>'
                );
                $("#add-post-form").show();
            }
        });
    });




    
})(jQuery);

