<div id="add_post_status"></div>
<form id="add-post-form" class="mt-4">
        <div class="form-group">
            <label>Title</label>
            <input type="text" class="form-control" id="apf_inputTitle"/>
        </div>   
        <hr>
        CONTENT_EDITOR        
        <div class="form-group">
            <button type="submit" class="btn btn-primary mt-4 btn-block">Submit Post</button>
        </div>
    </form>