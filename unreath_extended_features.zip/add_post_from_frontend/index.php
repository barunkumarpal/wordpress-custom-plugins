<?php
/* 
Plugin Name: Add Post from Frontend
Version: 1.0.0
Description: This plugin is to help you to add posts from frontend
Author: Barun
Text Domain: apf
*/

if( !defined('ABSPATH')){
    die;
}



// Plugin Path
define('APF_PLUGIN_URL', __FILE__);

$plugin_path = dirname(APF_PLUGIN_URL);

// Shortcode
include( $plugin_path.'/functions/add-post-frontend.php');
add_shortcode( 'front_end_form_addpost', 'apf_add_post_frontend' );

// Enqueue files
include( $plugin_path.'/enqueue/enqueue.php');
add_action('wp_enqueue_scripts', 'apf_enqueue_scripts', 100);

// Submit User Post   
include( $plugin_path.'/process/submit-post-process.php');

add_action('wp_ajax_apf_submit_user_post', 'apf_submit_post_process');
add_action('wp_ajax_nopriv_apf_submit_user_post', 'apf_submit_post_process');