<?php

/**
 * Plugin Name:       Elementor Custom Widgets
 * Description:       Extends Elementor Widgets
 * Version:           1.0.0
 * Author:            Barun
 * Text Domain:       ecw
 **/

 if( !defined('ABSPATH')){
     die('ABSPATH not defined!');
 }
 // Plugin Path

 $file_const = define('ECW_PLUGIN_PATH', __FILE__);

 $path = dirname(ECW_PLUGIN_PATH);

 $plugin_dir = define('ECW_DIR', $path);

 // Custom Widgets
 include( $path.'/custom_widgets.php');