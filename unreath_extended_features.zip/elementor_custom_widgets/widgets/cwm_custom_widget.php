<?php

namespace Elementor;

class Firstwidget extends Widget_Base{

    public function get_name() {
        return 'firstwidget';
    }

	public function get_title() {
        return 'ID Card';
    }

	public function get_icon() {
        return 'fa fa-id-card';
    }

	public function get_categories() {
        return ['general'];
    }

	protected function _register_controls() {

		// Content section
        $this->start_controls_section(
			'content_section',
			[
				'label' => __('Content', 'ecw'),
				'tab'=>Controls_Manager::TAB_CONTENT
				
			]
		);

		// Style tab
		$this->add_control(
			'tab-style',
			[
				'label' => 'Style',
				'tab'=>Controls_Manager::TAB_STYLE
				
			]
		);

		// Media Controld to upload Image
		
		$this->add_control(
			'id_image',
			[
				'label' => __( 'Choose Image', 'ecw' ),
				'type' => \Elementor\Controls_Manager::MEDIA,				
			]
		);

		// WYSIWYG Control
		$this->add_control(
			'item_description',
			[
				'label' => __( 'Description', 'ecw' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'Default description', 'ecw' ),
				'placeholder' => __( 'Type your description here', 'ecw' ),
			]
		);

		$this->end_controls_section();

    }

	// Get data to show on frontend
	protected function render() {
		$settings = $this->get_settings_for_display();
?>
	<div class="row">
		<!-- Image -->
		<div class="col-md-6">
			<img src="<?php echo $settings['id_image']['url']; ?>" alt="">
		</div>

		<!-- Description -->
		<div class="col-md-6">
			<p><?php echo $settings['item_description']; ?></p>
		</div>	
	</div>

<?php
    }

    protected function _content_template() { 
?>        
		<div class="row">
		<!-- Image -->
		<div class="col-md-6">
			<img src="{{ settings.id_image.url }}" alt="">
		</div>

		<!-- Description -->
		<div class="col-md-6">
			<p>{{{ settings.item_description }}}</p>
		</div>	
	</div>

<?php
	}
    
}

Plugin::instance()->widgets_manager->register_widget_type( new Firstwidget() );