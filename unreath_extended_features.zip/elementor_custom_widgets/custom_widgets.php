<?php

class ElementorCustomElement{

    private static $instance = null;

    public static function get_instance(){      

        if( is_null(self::$instance) ){

            self::$instance = new self();

        }

        return self::$instance;
    }

   

    public function cwm_widgets_registered(){
        
        if(defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')){

            

            $widget_file = ECW_DIR.'/widgets/cwm_custom_widget.php';
            $template_file = locate_template( $widget_file );

            if( !$template_file || !is_readable($template_file) ){
                $template_file = ECW_DIR.'/widgets/cwm_custom_widget.php';
            } 
            
            if( $template_file || is_readable($template_file) ){
                require_once $template_file;
            }           

            
        }
    }

    public function init(){
        
        add_action('elementor/widgets/widgets_registered', array($this, 'cwm_widgets_registered'), 99);

    }

}

ElementorCustomElement::get_instance()->init();