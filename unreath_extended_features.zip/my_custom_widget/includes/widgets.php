<?php
function mcw_widgets_init(){
    register_widget('mcw_widget_one');
}