<?php
function ur_create_custom_post(){
    
    // Register Post type Team
    $labels=array(
        'name'                  => _x( 'Team', 'Post type general name', 'urexf' ),
        'singular_name'         => _x( 'Team Member', 'Post type singular name', 'urexf' ),
        'menu_name'             => _x( 'Team', 'Admin Menu text', 'urexf' ),
        'name_admin_bar'        => _x( 'Team Member', 'Add New on Toolbar', 'urexf' ),
        'add_new'               => __( 'Add New Member', 'urexf' ),
        'add_new_item'          => __( 'Add New Member', 'urexf' ),
        'new_item'              => __( 'New Member', 'urexf' ),
        'edit_item'             => __( 'Edit Member', 'urexf' ),
        'view_item'             => __( 'View Member', 'urexf' ),
        'all_items'             => __( 'All Members', 'urexf' ),
        'search_items'          => __( 'Search Members', 'urexf' ),
        'parent_item_colon'     => __( 'Parent Members:', 'urexf' ),
        'not_found'             => __( 'No member found.', 'urexf' ),
        'not_found_in_trash'    => __( 'No member found in Trash.', 'urexf' ),
        'featured_image'        => _x( 'Member Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'urexf' ),
        'set_featured_image'    => _x( 'Set member image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'urexf' ),
        'remove_featured_image' => _x( 'Remove member image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'urexf' ),
        'use_featured_image'    => _x( 'Use as member image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'urexf' ),
        'archives'              => _x( 'Member archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'urexf' ),
        'insert_into_item'      => _x( 'Insert into Team', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'urexf' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this book', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'urexf' ),
        'filter_items_list'     => _x( 'Filter team list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'urexf' ),
        'items_list_navigation' => _x( 'Team list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'urexf' ),
        'items_list'            => _x( 'Team list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'urexf' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'team' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_rest'       => true,
        'menu_icon'           => 'dashicons-groups'
    );

    register_post_type( 'team', $args );


    // Register Post type FAQ
    $labels=array(
        'name'                  => _x( 'FAQs', 'Post type general name', 'urexf' ),
        'singular_name'         => _x( 'FAQ', 'Post type singular name', 'urexf' ),
        'menu_name'             => _x( 'FAQ', 'Admin Menu text', 'urexf' ),
        'name_admin_bar'        => _x( 'FAQ', 'Add New on Toolbar', 'urexf' ),
        'add_new'               => __( 'Add New FAQ', 'urexf' ),
        'add_new_item'          => __( 'Add New FAQ', 'urexf' ),
        'new_item'              => __( 'New FAQ', 'urexf' ),
        'edit_item'             => __( 'Edit FAQ', 'urexf' ),
        'view_item'             => __( 'View FAQ', 'urexf' ),
        'all_items'             => __( 'All FAQs', 'urexf' ),
        'search_items'          => __( 'Search FAQs', 'urexf' ),
        'parent_item_colon'     => __( 'Parent FAQs:', 'urexf' ),
        'not_found'             => __( 'No FAQ found.', 'urexf' ),
        'not_found_in_trash'    => __( 'No FAQ found in Trash.', 'urexf' ),        
        'archives'              => _x( 'FAQ archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'urexf' ),        'insert_into_item'      => _x( 'Insert into FAQ', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'urexf' ),      
        );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'faq' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor'),
        'show_in_rest'       => true,
        'menu_icon'           => 'dashicons-admin-comments'
    );

    register_post_type( 'faq', $args );

    // Register Post Type Press
    // Register Post type Team
    $labels=array(
        'name'                  => _x( 'News', 'Post type general name', 'urexf' ),
        'singular_name'         => _x( 'News', 'Post type singular name', 'urexf' ),
        'menu_name'             => _x( 'News', 'Admin Menu text', 'urexf' ),
        'name_admin_bar'        => _x( 'News', 'Add New on Toolbar', 'urexf' ),
        'add_new'               => __( 'Add New News', 'urexf' ),
        'add_new_item'          => __( 'Add New News', 'urexf' ),
        'new_item'              => __( 'New News', 'urexf' ),
        'edit_item'             => __( 'Edit News', 'urexf' ),
        'view_item'             => __( 'View News', 'urexf' ),
        'all_items'             => __( 'All News', 'urexf' ),
        'search_items'          => __( 'Search News', 'urexf' ),
        'parent_item_colon'     => __( 'Parent News:', 'urexf' ),
        'not_found'             => __( 'No News found.', 'urexf' ),
        'not_found_in_trash'    => __( 'No News found in Trash.', 'urexf' ),
        'featured_image'        => _x( 'News Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'urexf' ),
        'set_featured_image'    => _x( 'Set News image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'urexf' ),
        'remove_featured_image' => _x( 'Remove News image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'urexf' ),
        'use_featured_image'    => _x( 'Use as News image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'urexf' ),
        'archives'              => _x( 'News archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'urexf' ),
        'insert_into_item'      => _x( 'Insert into News', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'urexf' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this News', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'urexf' ),
        'filter_items_list'     => _x( 'Filter News list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'urexf' ),
        'items_list_navigation' => _x( 'News list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'urexf' ),
        'items_list'            => _x( 'News list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'urexf' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'news' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_rest'       => true,
        'menu_icon'           => 'dashicons-media-document'
    );

    register_post_type( 'news', $args );



    // Register Taxonomy Designation

    $labels = array(
        'name' => _x( 'Designation', 'taxonomy general name' ),
        'singular_name' => _x( 'Designation', 'taxonomy singular name' ),
        'search_items' =>  __( 'Search Designation' ),
        'popular_items' => __( 'Popular Topics' ),
        'all_items' => __( 'All Designation' ),
        'parent_item' => null,
        'parent_item_colon' => null,
        'edit_item' => __( 'Edit Designation', 'urexf' ), 
        'update_item' => __( 'Update Designation', 'urexf' ),
        'add_new_item' => __( 'Add New Designation', 'urexf' ),
        'new_item_name' => __( 'New Designation Name', 'urexf'),
        'separate_items_with_commas' => __( 'Separate topics with commas', 'urexf' ),
        'add_or_remove_items' => __( 'Add or remove resignation', 'urexf' ),
        'choose_from_most_used' => __( 'Choose from the most used topics', 'urexf' ),
        'menu_name' => __( 'Designation' ),
      ); 
     
    // Now register the non-hierarchical taxonomy like tag
     
      register_taxonomy('designation','team',array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var' => true,
        'rewrite' => array( 'slug' => 'designation' ),
        'show_in_rest' => true
      ));
}