<?php
function ur_activation_hook(){

    ur_create_custom_post();
    flush_rewrite_rules();
}