<?php
if( !defined( 'WP_UNINSTALLED_PLUGIN' ) ){    
   global $wpdb;
   $sql_query = "DELETE FROM wp_postmeta where post_id IN (SELECT ID from wp_posts where post_type = 'team' )";
   $wpdb->query($sql_query);


//    $sql_query = "DELETE FROM wp_comments where comment_post_ID IN (SELECT ID from wp_posts where post_type = 'team' )";
//    $wpdb->query($sql_query);


   $sql_query = "DELETE from wp_posts where post_type = 'team'";
    $wpdb->query($sql_query);
}