<?php
/* 
Plugin Name: Unreath Extended Features
Version: 1.0.0
Description: This plugin extends features of the theme Unreath
Author: Barun
Text Domain: urexf
*/

if( !defined('ABSPATH')){
    die;
}

if(!function_exists('add_action')){
    exit;
}



// Plugin Path
define('UREXF_PLUGIN_URL', __FILE__);

$plugin_path = dirname(UREXF_PLUGIN_URL);

// Register Post type
include( $plugin_path.'/includes/create_custom_post.php');
add_action('init', 'ur_create_custom_post');

// Activate Plugin
include( $plugin_path.'/activate.php');
register_activation_hook(__FILE__, 'ur_activation_hook' );




