<?php
/* 
Plugin Name: Custom Mega Menu
Version: 1.0.0
Description: Testing to create a Mega Menu
Author: Barun
Text Domain: mcw
*/

if( !defined('ABSPATH')){
    die;
}

if(!function_exists('add_action')){
    exit;
}



// Plugin Path
define('CMM_PLUGIN_URL', __FILE__);

$plugin_path = dirname(CMM_PLUGIN_URL);

// Create Widget
include( $plugin_path.'/custom-walker-nav.php');

