(function($){   

    // User Register form submit
    $(document).on('submit', '#custom_register_form', function(e){
       
            e.preventDefault();
    
            
            $("#register_status").html(
                '<div class="alert alert-info">Please wait! We are submitting your details.</div>'
            );
            $(this).hide();

            var form = {
                _wpnonce: $('#_wpnonce').val(),
                action: 'clrs_register_user',                
                name: $('#name').val(),
                username: $('#username').val(),
                email: $('#email').val(),
                password: $('#pwd').val(),
                conf_password: $('#cnf_pwd').val()
               
            }

           
    
            $.post(clrs_wp_ajax_obj.ajax_url, form). always(function(data){
                if(data.status == 2){
                    $('#register_status').html(
                        '<div class="alert alert-success">Registration successful!</div>'
                    );

                    location.href = clrs_wp_ajax_obj.home_url;
                } else{
                    $('#register_status').html(
                        '<div class="alert alert-danger">Unable to register. Please fill in all fields.</div>'
                    );
                    $("#register_status").show();
                }
            });
        });
    
    
    
    // Login form submit
    // $(document).ready(
    //     $('#login_form').hide()
    // );

    $(document).on('submit', '#login_form', function(e){
       
        e.preventDefault();

        
        $("#login_status").html(
            '<div class="alert alert-info">Please wait! We are submitting your details.</div>'
        );
        $(this).hide();

        var form = {
            _wpnonce: $('#_wpnonce').val(),
            action: 'clrs_login_user',       
            username: $('#username').val(),           
            password: $('#pwd').val(), 
            rememberme: $('#rememberme').val()          
           
        }

       

        $.post(clrs_wp_ajax_obj.ajax_url, form). always(function(data){
            if(data.status == 2){
                $('#login_status').html(
                    '<div class="alert alert-success">Login successful!</div>'
                );

                location.href = clrs_wp_ajax_obj.home_url;
            } else{
                $('#login_status').html(
                    '<div class="alert alert-danger">Unable to login. Please fill in all fields.</div>'
                );
                $("#login_form").show();
            }
        });
    });
        
    })(jQuery);
    
    