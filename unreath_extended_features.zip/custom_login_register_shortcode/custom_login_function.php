<?php
function clrs_custom_login(){
    
    if(is_user_logged_in()){
        return '';
    }
    $formHTML = file_get_contents( plugins_url('/templates/custom_login_template.php', CLRS_PLUGIN_URL) , true );
    $formHTML = str_replace(
        'NONCE_FIELD_PH',

         wp_nonce_field(
            'user_login_auth', 
            '_wpnonce',
            true,
            false
         ),

         $formHTML

 );

    return $formHTML;
}