<div class="row">
    <!-- Login Form -->
    <div class="col-md-4"></div>
    <div class="col-md-4 bg-dark p-4 mb-4 mt-4">

        <div id="login_status"></div>

        <h3 class="text-center text-white">User Login</h3>
        NONCE_FIELD_PH
        <form method="POST" id="login_form">
            <div class="form-group">                            
                <input type="text" id="username" class="form-control" placeholder="Username / Email">
            </div>
            
            <div class="form-group">                            
                <input type="password" id="pwd" class="form-control" placeholder="Password">
            </div>  

            <div class="row">
                <div class="col-md-12">
                    <label class="pull-left checkbox-inline text-white">
                        <input type="checkbox" id="rememberme" name="rememberme" value="forever">
                            Remember me
                    </label>
                </div>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-block btn-primary">Login</button>
                </div>
            </div>            

        </form>
    </div>
    <div class="col-md-4"></div>
</div>
