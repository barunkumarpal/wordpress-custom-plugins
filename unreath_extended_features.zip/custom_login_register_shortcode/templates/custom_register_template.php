  <div class="row">
        
        <!-- Login Form -->
        <div class="col-md-4"></div>
        <div class="col-md-4 bg-dark p-4 mb-4 mt-4">              

            <h3 class="text-center text-white">New User Registration</h3>
            NONCE_FIELD_PH
            <div id="register_status"></div>
            <form method="POST" id="custom_register_form">

                <div class="form-group">                            
                    <input type="text" id="name" class="form-control" placeholder="Your Name" value='<?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?>'>
                </div>

                <div class="form-group">                            
                    <input type="text"  id="username" class="form-control" placeholder="Username" value='<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>'>
                </div>
                
                <div class="form-group">                            
                    <input type="email"  id="email" class="form-control" placeholder="Email" value='<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>'>
                </div>
                
                <div class="form-group">                            
                    <input type="password" id="pwd" class="form-control" placeholder="Password">
                </div>  

                <div class="form-group">                            
                    <input type="password"  id="cnf_pwd" class="form-control" placeholder="Re-enter Password">
                </div>  

                <div class="row">                                                       
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-block btn-primary">Submit</button>
                    </div>
                </div>            

            </form>

            <h3 class="text-center text-white mt-3 mb-3">Already Registered?</h3>
            <p class="text-center">
                <a href="/wp-april-20-practice/custom_login" class="btn btn-warning">Log in</a>
            </p>
            
        </div>
        <div class="col-md-4"></div>

    </div>   

  <?php //} ?> 
