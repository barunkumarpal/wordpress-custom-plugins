<?php 
function clrs_custom_register(){
    if(is_user_logged_in()){
        return '';
    }
    $creatorHTML = file_get_contents( plugins_url('/templates/custom_register_template.php', CLRS_PLUGIN_URL) , true); 
    $creatorHTML = str_replace(
        'NONCE_FIELD_PH',
        wp_nonce_field(
            'wp_nonce_auth',
            '_wpnonce',
            true,
            false
        ),
        $creatorHTML     
    );
    
    
    return $creatorHTML;
}


