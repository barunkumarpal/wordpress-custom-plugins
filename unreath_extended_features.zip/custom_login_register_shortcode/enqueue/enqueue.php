<?php

function clrs_enqueue_scripts(){
    wp_register_script('clrs_main_js', plugins_url('/js/main.js', CLRS_PLUGIN_URL),
    ['jquery'], '1.0.0', true );

    wp_localize_script('clrs_main_js', 'clrs_wp_ajax_obj', [ 
        'ajax_url' => admin_url('admin-ajax.php'),
        'home_url' => home_url('/')
        ]);

    wp_enqueue_script('clrs_main_js');
}