<?php
/*

Plugin Name: Custom login & register shortcode
Description: Provides shortcode & processes custom login & register
Version: 1.0.0
Author: Barun
Text Domain: clrs



*/

if( !defined('ABSPATH')){
    die;
}

if(!function_exists('add_action')){
    echo "You can't call me directly!";
    exit;
}

// Setup

define('CLRS_PLUGIN_URL', __FILE__);
$plugin_path = dirname(CLRS_PLUGIN_URL);

// Enqueue files
include( $plugin_path.'/enqueue/enqueue.php');
add_action('wp_enqueue_scripts', 'clrs_enqueue_scripts', 100);

// Shortcode Register
include( $plugin_path.'/custom_register_function.php');
add_shortcode('register_custom_form', 'clrs_custom_register');


// New User Register Process 
include( $plugin_path.'/process/register-user-process.php');

add_action('wp_ajax_nopriv_clrs_register_user', 'clrs_register_user_process');

// Login shortcode
include( $plugin_path.'/custom_login_function.php');
add_shortcode('login_custom_form', 'clrs_custom_login');

// Login user process
include( $plugin_path.'/process/login-user-process.php');

add_action('wp_ajax_nopriv_clrs_login_user', 'clrs_login_user_process');
